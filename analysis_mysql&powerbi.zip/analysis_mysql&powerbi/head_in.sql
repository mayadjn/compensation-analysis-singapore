SELECT 
  year_quarter,
  Industry,
  compensation
FROM comp_long
WHERE Industry IN ('Manufacturing', 'Finance&Insurance', 'Information&Communications')
  AND year_quarter >= '2015-1Q';