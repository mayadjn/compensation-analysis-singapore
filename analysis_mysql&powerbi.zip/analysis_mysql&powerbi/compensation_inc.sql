-- 1. 各行业薪资年增长率（2024 vs 2015）
SELECT 
  Industry,
  ROUND((MAX(CASE WHEN year_quarter LIKE '2024%' THEN compensation END) / 
        MAX(CASE WHEN year_quarter LIKE '2015%' THEN compensation END) - 1)*100, 1) AS growth_pct
FROM comp_long
GROUP BY Industry
ORDER BY growth_pct DESC;